<?php
 include "database.php";
 $db = new Database;

 $aksi = $_GET['aksi'];

 if ($aksi=="tambah") {
    $db->tambahData($_POST['nama'], $_POST['alamat'], $_POST['nohp'], $_POST['jeniskelamin'],$_FILES['foto']['name']);
    header("location:index.php");
 }
 elseif($aksi=="update"){
    $db->updateData($_POST['id'],$_POST['nama'], $_POST['alamat'], $_POST['nohp'],$_POST['jeniskelamin'],$_FILES['foto']['name']);
    header("location:index.php");
 }
 elseif($aksi=="hapus"){
    $db->hapusData($_GET['id']);
    header("location:index.php");
 }
?>